package com.zeeshanrajafyp.goodexchangeapp;

import android.content.Intent;
import android.media.Image;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.Layout;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Picasso;
import com.zeeshanrajafyp.goodexchangeapp.Data.ProductInfo;
import com.zeeshanrajafyp.goodexchangeapp.Data.StaticData;

import org.w3c.dom.Text;

public class CategoryItems extends AppCompatActivity {

    RecyclerView recyclerView;
    FirebaseRecyclerAdapter<ProductInfo, ViewHolder> adapter;
    DatabaseReference databaseRef;
    String currentCat = "";
    TextView noItemExistsTv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category_items);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


//        Log.d("CurrentCate", ""+StaticData.currentCategory);

        recyclerView = (RecyclerView) findViewById(R.id.itemRecyclerViews);
        noItemExistsTv = (TextView) findViewById(R.id.noItemExistsTv);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
//        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        if(getIntent() != null){

            StaticData.currentCategory = getIntent().getStringExtra("cateName");
            Toast.makeText(this, ""+StaticData.currentCategory, Toast.LENGTH_SHORT).show();
            getSupportActionBar().setTitle(StaticData.currentCategory);

        }


         databaseRef = FirebaseDatabase.getInstance().getReference("CategoryItems").child(StaticData.currentCategory);




        initalizedAdapter();

    }

    private void initalizedAdapter() {

        FirebaseRecyclerOptions<ProductInfo> options = new FirebaseRecyclerOptions.Builder<ProductInfo>().setQuery(databaseRef.orderByKey(), ProductInfo.class).build();

        adapter = new FirebaseRecyclerAdapter<ProductInfo, ViewHolder>(options) {
            @Override
            protected void onBindViewHolder(@NonNull ViewHolder holder, int position, @NonNull final ProductInfo model) {
                Picasso.with(CategoryItems.this).load(model.getImage()).into(holder.imageView);
                if(adapter.getItemCount() > 0 ){
                    noItemExistsTv.setVisibility(View.GONE);
                }
                holder.titleTv.setText(model.getName());
                holder.priceTxt.setText("Rs:"+model.getPrice());

                holder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(CategoryItems.this, ProductDetail.class);

                        intent.putExtra("name", model.getName());
                        intent.putExtra("image", model.getImage());
                        intent.putExtra("desc", model.getDesc());
                        intent.putExtra("price", model.getPrice());
                        intent.putExtra("address", model.getAddress());
                        intent.putExtra("wantTitle", model.getWpTitle());
                        intent.putExtra("wantDesc", model.getDesc());
                        intent.putExtra("wantImage", model.getWpImage());
                        intent.putExtra("uid", model.getUid());
                        intent.putExtra("postBy", model.getPostUserName());


                        startActivity(intent);
                    }
                });

            }

            @NonNull
            @Override
            public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
                View itemView = LayoutInflater.from(getApplicationContext()).inflate(R.layout.item_detail_layout, viewGroup, false);
                return new ViewHolder(itemView);
            }
        };
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();

    }

    class ViewHolder extends RecyclerView.ViewHolder{

        ImageView imageView;
        TextView titleTv, priceTxt;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            imageView = (ImageView) itemView.findViewById(R.id.itemImage);
            titleTv = (TextView) itemView.findViewById(R.id.itemTitle);
            priceTxt = (TextView) itemView.findViewById(R.id.itemPrice);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();

        adapter.startListening();
    }


    @Override
    protected void onStop() {
        adapter.stopListening();
        super.onStop();

    }


}
