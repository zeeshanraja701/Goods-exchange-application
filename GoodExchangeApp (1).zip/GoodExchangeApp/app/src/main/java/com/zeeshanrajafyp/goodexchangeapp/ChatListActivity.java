package com.zeeshanrajafyp.goodexchangeapp;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.zeeshanrajafyp.goodexchangeapp.Data.MessageInfo;
import com.zeeshanrajafyp.goodexchangeapp.Data.UserData;

import org.w3c.dom.Text;

public class ChatListActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    DatabaseReference databaseReference, userDatabase;
    FirebaseRecyclerAdapter<MessageInfo, ViewHolder> adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_list);

        databaseReference = FirebaseDatabase.getInstance().getReference("Chat").child(FirebaseAuth.getInstance().getCurrentUser().getUid());

        userDatabase = FirebaseDatabase.getInstance().getReference("Users");

        recyclerView = (RecyclerView) findViewById(R.id.chatList);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));


        initializeAdapter();


    }

    private void initializeAdapter() {
        FirebaseRecyclerOptions<MessageInfo> options = new FirebaseRecyclerOptions.Builder<MessageInfo>().setQuery(databaseReference, MessageInfo.class).build();

        adapter  = new FirebaseRecyclerAdapter<MessageInfo, ViewHolder>(options) {
            @Override
            protected void onBindViewHolder(@NonNull final ViewHolder holder, final int position, @NonNull MessageInfo model) {

                if(FirebaseAuth.getInstance().getCurrentUser().getUid() != adapter.getRef(position).getKey()) {

                    userDatabase.child(adapter.getRef(position).getKey()).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                            UserData userInfo = dataSnapshot.getValue(UserData.class);
                            holder.textView.setText(userInfo.getName());
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });

                    holder.itemView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            Intent intent = new Intent(ChatListActivity.this, ChatingActivity.class);
                            intent.putExtra("uid", adapter.getRef(position).getKey());
                            startActivity(intent);
                        }
                    });
                }
            }

            @NonNull
            @Override
            public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
                View itemView = LayoutInflater.from(getApplicationContext()).inflate(R.layout.chat_user_layout, viewGroup, false);
                return new ViewHolder(itemView);
            }
        };
        adapter.notifyDataSetChanged();
        recyclerView.setAdapter(adapter);
    }

    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening();
    }


    @Override
    protected void onStop() {
        adapter.stopListening();
        super.onStop();
    }

    class ViewHolder extends RecyclerView.ViewHolder{

        TextView textView;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textView = (TextView) itemView.findViewById(R.id.chatUserName);

        }
    }
}
