package com.zeeshanrajafyp.goodexchangeapp;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.UserInfo;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.zeeshanrajafyp.goodexchangeapp.Data.MessageInfo;
import com.zeeshanrajafyp.goodexchangeapp.Data.Notification;
import com.zeeshanrajafyp.goodexchangeapp.Data.Sender;
import com.zeeshanrajafyp.goodexchangeapp.Data.StaticData;
import com.zeeshanrajafyp.goodexchangeapp.Data.UserData;
import com.zeeshanrajafyp.goodexchangeapp.Server.MessagingService;
import com.zeeshanrajafyp.goodexchangeapp.Server.ServerResponse;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ChatingActivity extends AppCompatActivity {

    DatabaseReference userReference, chatReference;
    RecyclerView recyclerView;
    FirebaseRecyclerAdapter<MessageInfo, ViewHolder> adapter;
    String uid;
    EditText messageEt;
    Button sendMessageBtn;
    TextView toolBarTextView;
    UserData userInfo;
    MessagingService messagingService;
    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chating);

        messagingService = StaticData.getService();
        final Toolbar toolbar = (Toolbar) findViewById(R.id.chattoolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("");
        toolBarTextView = (TextView) toolbar.findViewById(R.id.chatusername);

        recyclerView = (RecyclerView) findViewById(R.id.chatRecyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        if(getIntent().getExtras() != null) {
            uid = getIntent().getStringExtra("uid");
            userReference = FirebaseDatabase.getInstance().getReference("Users").child(uid);
            databaseReference = FirebaseDatabase.getInstance().getReference("tokens");

            chatReference = FirebaseDatabase.getInstance().getReference();


            userReference.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                     userInfo = dataSnapshot.getValue(UserData.class);
                    toolBarTextView.setText(userInfo.getName());
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });



        }

        initializedAdapter();

        messageEt = (EditText) findViewById(R.id.messageEditText);

        sendMessageBtn = (Button) findViewById(R.id.sendButton);
        sendMessageBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!TextUtils.isEmpty(messageEt.getText().toString())) {
                    final MessageInfo messageInfo = new MessageInfo(messageEt.getText().toString(), FirebaseAuth.getInstance().getCurrentUser().getUid());
                    chatReference.child("Chat").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child(uid).push().setValue(messageInfo)
                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if(task.isSuccessful())
                                        chatReference.child("Chat").child(uid).child(FirebaseAuth.getInstance().getCurrentUser().getUid()).push().setValue(messageInfo);


                                    messageEt.setText("");
                                }
                            });


                    databaseReference.child(uid).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            String userToken =  dataSnapshot.child("token").getValue().toString();
                            Log.d("token", userToken);

                            Notification notification = new Notification("chatNotification", "You receive new message.");
                            Sender data = new Sender(userToken, notification);
                            messagingService.sendMessage(data).enqueue(new Callback<ServerResponse>() {
                                @Override
                                public void onResponse(Call<ServerResponse> call, Response<ServerResponse> response) {
                                    if(response.body().success == 1){
//                                        Toast.makeText(ChatingActivity.this, "Go Message Send!", Toast.LENGTH_SHORT).show();
                                    }else{
                                        Toast.makeText(ChatingActivity.this, "Message Sending Failed!", Toast.LENGTH_SHORT).show();
                                    }
                                }

                                @Override
                                public void onFailure(Call<ServerResponse> call, Throwable t) {

                                    Log.e("Error", t.getMessage());
                                }
                            });

                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });

                }
            }
        });





    }

    private void initializedAdapter() {

        FirebaseRecyclerOptions<MessageInfo> options = new FirebaseRecyclerOptions.Builder<MessageInfo>().setQuery(chatReference.child("Chat").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child(uid), MessageInfo.class).build();
        adapter = new FirebaseRecyclerAdapter<MessageInfo, ViewHolder>(options) {
            @Override
            protected void onBindViewHolder(@NonNull ViewHolder holder, int position, @NonNull MessageInfo model) {


                if(model.getKey().equals(FirebaseAuth.getInstance().getCurrentUser().getUid())){
                    holder.messageTv.setVisibility(View.GONE);

                }else{
                    holder.messageTv1.setVisibility(View.GONE);


                }
                holder.messageTv.setText(model.getMessage());
                holder.messageTv1.setText(model.getMessage());

            }

            @NonNull
            @Override
            public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
                View itemView = LayoutInflater.from(getApplicationContext()).inflate(R.layout.message_layout_item, viewGroup, false);
                return new ViewHolder(itemView);
            }
        };
        adapter.notifyDataSetChanged();
        recyclerView.setAdapter(adapter);
    }


    class ViewHolder extends RecyclerView.ViewHolder{

        TextView messageTv, messageTv1;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            messageTv = (TextView) itemView.findViewById(R.id.messageTextLeft);
            messageTv1 = (TextView) itemView.findViewById(R.id.messageTextRight);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening();

    }

    @Override
    protected void onStop() {
        adapter.startListening();
        super.onStop();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.chat_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == R.id.chat_action_call){
            if(userInfo != null) {
                callToOwner();
            }
        }

        return super.onOptionsItemSelected(item);
    }

    private void callToOwner() {

        if (ActivityCompat.checkSelfPermission(ChatingActivity.this,
                Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {

            phoneCall();
        }else {
            final String[] PERMISSIONS_STORAGE = {Manifest.permission.CALL_PHONE};
            //Asking request Permissions
            ActivityCompat.requestPermissions(ChatingActivity.this, PERMISSIONS_STORAGE, 9);
        }

    }

    private void phoneCall() {

        if (ActivityCompat.checkSelfPermission(ChatingActivity.this,
                Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
            Intent callIntent = new Intent(Intent.ACTION_CALL);
            callIntent.setData(Uri.parse("tel:"+userInfo.getPhone()));
            startActivity(callIntent);
        }else{
            Toast.makeText(ChatingActivity.this, "You don't assign permission.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        boolean permissionGranted = false;
        switch(requestCode){
            case 9:
                permissionGranted = grantResults[0]== PackageManager.PERMISSION_GRANTED;
                break;
        }
        if(permissionGranted){
            phoneCall();
        }else {
            Toast.makeText(ChatingActivity.this, "You don't assign permission.", Toast.LENGTH_SHORT).show();
        }
    }

}
