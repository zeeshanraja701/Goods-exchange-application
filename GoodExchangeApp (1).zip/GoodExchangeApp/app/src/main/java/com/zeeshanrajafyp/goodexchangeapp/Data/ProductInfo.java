package com.zeeshanrajafyp.goodexchangeapp.Data;

public class ProductInfo {

    String name, price, desc, image, address, city, wpImage, wpTitle, wpDesc, uid, postUserName;

    public ProductInfo(){

    }

    public ProductInfo(String name, String price, String desc, String image, String address, String city, String wpImage, String wpTitle, String wpDesc, String uid, String postUserName) {
        this.name = name;
        this.price = price;
        this.desc = desc;
        this.image = image;
        this.address = address;
        this.city = city;
        this.wpImage = wpImage;
        this.wpTitle = wpTitle;
        this.wpDesc = wpDesc;
        this.uid = uid;
        this.postUserName = postUserName;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }


    public String getWpImage() {
        return wpImage;
    }

    public void setWpImage(String wpImage) {
        this.wpImage = wpImage;
    }

    public String getWpTitle() {
        return wpTitle;
    }

    public void setWpTitle(String wpTitle) {
        this.wpTitle = wpTitle;
    }

    public String getWpDesc() {
        return wpDesc;
    }

    public void setWpDesc(String wpDesc) {
        this.wpDesc = wpDesc;
    }

    public String getPostUserName() {
        return postUserName;
    }

    public void setPostUserName(String postUserName) {
        this.postUserName = postUserName;
    }
}
