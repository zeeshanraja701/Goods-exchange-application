package com.zeeshanrajafyp.goodexchangeapp.Data;

import com.zeeshanrajafyp.goodexchangeapp.Server.Client;
import com.zeeshanrajafyp.goodexchangeapp.Server.MessagingService;

public class StaticData {

    public static UserData currentUser = null;


    public static  String currentCategory = "";

    public static String CategoryNames[] = {"Mobiles", "Electronics", "Cars", "Clothes","Furniture", "Shoes","MotorBikes"," Baby & Kids","Accessories" ,"Others"};


    public static final String messageingUrl = "https://fcm.googleapis.com/";


    public static MessagingService getService(){
        return Client.getClient(messageingUrl).create(MessagingService.class);
    }
}
