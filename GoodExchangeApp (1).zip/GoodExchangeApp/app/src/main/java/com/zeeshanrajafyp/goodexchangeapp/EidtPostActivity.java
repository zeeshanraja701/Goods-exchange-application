package com.zeeshanrajafyp.goodexchangeapp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.AppCompatEditText;
import android.support.v7.widget.AppCompatSpinner;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;
import com.zeeshanrajafyp.goodexchangeapp.Data.ProductInfo;
import com.zeeshanrajafyp.goodexchangeapp.Data.StaticData;

import org.w3c.dom.Text;

import java.util.UUID;

public class EidtPostActivity extends AppCompatActivity {

    private static final int REQ_CODE_HAVE = 99;
    private static final int REQ_CODE_WANT = 100;
    private ImageButton imageBtn, wantImage;
    private AppCompatEditText postTitle, postDesc, postPrice, postAddress, postCity, wantTitle, wantDesc;
    String name, price, desc, image, address, city,wpImage, wpTitle, wpDesc, uid, postId;
    private AppCompatButton postBtn;
    private AppCompatSpinner spinner;
    private DatabaseReference databaseReference;
    private ProductInfo productInfo;

    private Uri haveimageUri, wantImageUri;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eidt_post);

        databaseReference = FirebaseDatabase.getInstance().getReference("CategoryItems");

        if(getIntent() != null){



            name = getIntent().getStringExtra("name");
            price = getIntent().getStringExtra("price");
            desc = getIntent().getStringExtra("desc" );
            image = getIntent().getStringExtra("image");
            address = getIntent().getStringExtra("address");
            city = getIntent().getStringExtra("city");
            wpImage = getIntent().getStringExtra("wpImage");
            wpTitle = getIntent().getStringExtra("wpTitle");
            wpDesc = getIntent().getStringExtra("wpDesc");
            uid = getIntent().getStringExtra("uid" );
            postId = getIntent().getStringExtra("postId");
            productInfo = new ProductInfo(name,price, desc, image, address, city, wpImage, wpTitle, wpDesc, uid, StaticData.currentUser.getName());
            wantImageUri = Uri.parse(wpImage);
            haveimageUri = Uri.parse(image);
            Toast.makeText(this, ""+name, Toast.LENGTH_SHORT).show();
        }

        imageBtn = (ImageButton) findViewById(R.id.sellItemImageBtn);
        postTitle = (AppCompatEditText) findViewById(R.id.postTitle);
        postDesc = (AppCompatEditText) findViewById(R.id.postDesc);
        postPrice = (AppCompatEditText) findViewById(R.id.postPrice);
        postAddress = (AppCompatEditText) findViewById(R.id.postAddress);
        postCity = (AppCompatEditText) findViewById(R.id.postCity);

        //for i want product
        wantImage = (ImageButton) findViewById(R.id.wantItemImageBtn);
        wantTitle = (AppCompatEditText) findViewById(R.id.wantProductTitle);
        wantDesc = (AppCompatEditText) findViewById(R.id.wantProductDesc);

        ArrayAdapter<String> adapter  = new ArrayAdapter<>(this, R.layout.spinner_item_layout, StaticData.CategoryNames);
        spinner = (AppCompatSpinner) findViewById(R.id.postCategory);
        int pos = adapter.getPosition(StaticData.currentCategory);
        spinner.setAdapter(adapter);
        spinner.setSelection(pos);



        Picasso.with(this).load(image).into(imageBtn);
        postTitle.setText(name);
        postDesc.setText(desc);
        postPrice.setText(price);
        postAddress.setText(address);
        postCity.setText(city);

        Picasso.with(this).load(wpImage).into(wantImage);
        wantTitle.setText(wpTitle);
        wantDesc.setText(wpDesc);
        postBtn = (AppCompatButton) findViewById(R.id.uploadPost);

        postBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                uploadData();
            }
        });

        imageBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SelectHaveProductImage();
            }
        });

        wantImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SelectProductWantImage();
            }
        });


    }

    private void SelectHaveProductImage() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_PICK);
        startActivityForResult(Intent.createChooser(intent,"Select Item Image"), REQ_CODE_HAVE);
    }

    private void SelectProductWantImage() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_PICK);
        startActivityForResult(Intent.createChooser(intent,"Select Item Image"), REQ_CODE_WANT);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        StorageReference imageRef = FirebaseStorage.getInstance().getReference();

        if (requestCode == REQ_CODE_HAVE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri saveUri = data.getData();
            if (saveUri != null) {
                final ProgressDialog progressDialog = new ProgressDialog(this);
                progressDialog.setMessage("Please Wait...");
                progressDialog.setCancelable(false);
                progressDialog.show();

                String name = UUID.randomUUID().toString();
                final StorageReference imageFolder = imageRef.child("images/" + name);
                imageFolder.putFile(saveUri)
                        .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {

                                imageFolder.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                    @Override
                                    public void onSuccess(Uri uri) {
                                        progressDialog.dismiss();
                                        haveimageUri = uri;
                                        Toast.makeText(EidtPostActivity.this, "Image Uploaded!", Toast.LENGTH_SHORT).show();

                                        Picasso.with(getApplicationContext()).load(haveimageUri).into(imageBtn);
                                    }
                                });
                            }
                        }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                        double progress = (100 * taskSnapshot.getBytesTransferred() / taskSnapshot.getTotalByteCount());
                        progressDialog.setMessage("Image Uploading " + progress + "%");

                    }
                });

            }



        }else if (requestCode == REQ_CODE_WANT && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri saveUri = data.getData();
            if (saveUri != null) {
                final ProgressDialog progressDialog = new ProgressDialog(this);
                progressDialog.setMessage("Please Wait...");
                progressDialog.setCancelable(false);
                progressDialog.show();

                String name = UUID.randomUUID().toString();
                final StorageReference imageFolder = imageRef.child("images/" + name);
                imageFolder.putFile(saveUri)
                        .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {

                                imageFolder.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                    @Override
                                    public void onSuccess(Uri uri) {
                                        progressDialog.dismiss();
                                        wantImageUri = uri;
                                        Toast.makeText(EidtPostActivity.this, "Image Uploaded!", Toast.LENGTH_SHORT).show();

                                        Picasso.with(getApplicationContext()).load(wantImageUri).into(wantImage);
                                    }
                                });
                            }
                        }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                        double progress = (100 * taskSnapshot.getBytesTransferred() / taskSnapshot.getTotalByteCount());
                        progressDialog.setMessage("Image Uploading " + progress + "%");

                    }
                });

            }



        }

    }

    private void uploadData() {

        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Please Wait...");
        progressDialog.setMessage("While uploading post!");
        progressDialog.setCancelable(false);

        String title = postTitle.getText().toString();
        String desc = postDesc.getText().toString();
        String price = postPrice.getText().toString();
        String address = postAddress.getText().toString();
        String city = postCity.getText().toString();
        String selectedCategory = (String) spinner.getSelectedItem();
        String wantProductTitle = wantTitle.getText().toString();
        String wantProductDesc = wantDesc.getText().toString();


        progressDialog.show();
        if(!TextUtils.isEmpty(title) && !TextUtils.isEmpty(desc) && !TextUtils.isEmpty(price) && !TextUtils.isEmpty(address)
                && !TextUtils.isEmpty(city) && !TextUtils.isEmpty(selectedCategory) && !TextUtils.isEmpty(String.valueOf(haveimageUri))
                && !TextUtils.isEmpty(String.valueOf(wantImageUri)) && !TextUtils.isEmpty(wantProductTitle) && !TextUtils.isEmpty(wantProductDesc)){


            ProductInfo productInfo = new ProductInfo(title, price, desc, String.valueOf(haveimageUri) ,address, city, String.valueOf(wantImageUri), wantProductTitle, wantProductDesc, FirebaseAuth.getInstance().getCurrentUser().getUid(), StaticData.currentUser.getName());
            databaseReference.child(selectedCategory).child(postId).setValue(productInfo).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if(task.isSuccessful()){
                        progressDialog.dismiss();
                        Intent intent = new Intent(EidtPostActivity.this, Home.class);
                        startActivity(intent);
                        finish();
                    }
                }
            });


        }else{
            progressDialog.dismiss();
            Toast.makeText(this, "Kindly fill required information!", Toast.LENGTH_SHORT).show();
        }
    }

}
