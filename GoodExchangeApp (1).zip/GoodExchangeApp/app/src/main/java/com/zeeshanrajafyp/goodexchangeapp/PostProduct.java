package com.zeeshanrajafyp.goodexchangeapp;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.Image;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.AppCompatEditText;
import android.support.v7.widget.AppCompatImageButton;
import android.support.v7.widget.AppCompatSpinner;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;
import com.zeeshanrajafyp.goodexchangeapp.Data.ProductInfo;
import com.zeeshanrajafyp.goodexchangeapp.Data.StaticData;
import com.zeeshanrajafyp.goodexchangeapp.Data.UserData;

import org.w3c.dom.Text;

import java.util.HashMap;
import java.util.UUID;

public class PostProduct extends AppCompatActivity {

    private static final int REQ_CODE_HAVE = 99;
    private static final int REQ_CODE_WANT = 100;
    private ImageButton imageBtn, wantImage;
    private AppCompatEditText postTitle, postDesc, postPrice, postAddress, postCity, wantTitle, wantDesc;
    private AppCompatButton postBtn;
    private AppCompatSpinner spinner;
    private DatabaseReference databaseReference;
    private Uri haveimageUri, wantImageUri;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_product);

        databaseReference = FirebaseDatabase.getInstance().getReference("CategoryItems");

        imageBtn = (ImageButton) findViewById(R.id.sellItemImageBtn);
        postTitle = (AppCompatEditText) findViewById(R.id.postTitle);
        postDesc = (AppCompatEditText) findViewById(R.id.postDesc);
        postPrice = (AppCompatEditText) findViewById(R.id.postPrice);
        postAddress = (AppCompatEditText) findViewById(R.id.postAddress);
        postCity = (AppCompatEditText) findViewById(R.id.postCity);

        //for i want product
        wantImage = (ImageButton) findViewById(R.id.wantItemImageBtn);
        wantTitle = (AppCompatEditText) findViewById(R.id.wantProductTitle);
        wantDesc = (AppCompatEditText) findViewById(R.id.wantProductDesc);


        spinner = (AppCompatSpinner) findViewById(R.id.postCategory);
        spinner.setAdapter(new ArrayAdapter<>(this, R.layout.spinner_item_layout, StaticData.CategoryNames));

        postBtn = (AppCompatButton) findViewById(R.id.uploadPost);
        postBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                uploadData();
            }
        });

        imageBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SelectHaveProductImage();
            }
        });

        wantImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SelectProductWantImage();
            }
        });

        checkPermissions();
    }

    private void checkPermissions() {

        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_CODE_HAVE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        switch (requestCode){
            case REQ_CODE_HAVE:
                if(grantResults.length > 0 &&  grantResults[0] == PackageManager.PERMISSION_GRANTED){
                    Toast.makeText(this, "Permission Granted!", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(this, "Permission Denied!!", Toast.LENGTH_SHORT).show();
                }
        }

    }

    private void SelectHaveProductImage() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_PICK);
        startActivityForResult(Intent.createChooser(intent,"Select Item Image"), REQ_CODE_HAVE);
    }

    private void SelectProductWantImage() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_PICK);
        startActivityForResult(Intent.createChooser(intent,"Select Item Image"), REQ_CODE_WANT);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        StorageReference imageRef = FirebaseStorage.getInstance().getReference();

        if (requestCode == REQ_CODE_HAVE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri saveUri = data.getData();
            if (saveUri != null) {
                final ProgressDialog progressDialog = new ProgressDialog(this);
                progressDialog.setMessage("Please Wait...");
                progressDialog.setCancelable(false);
                progressDialog.show();

                String name = UUID.randomUUID().toString();
                final StorageReference imageFolder = imageRef.child("images/" + name);
                imageFolder.putFile(saveUri)
                        .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {

                                imageFolder.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                    @Override
                                    public void onSuccess(Uri uri) {
                                        progressDialog.dismiss();
                                        haveimageUri = uri;
                                        Toast.makeText(PostProduct.this, "Image Uploaded!", Toast.LENGTH_SHORT).show();

                                        Picasso.with(getApplicationContext()).load(haveimageUri).into(imageBtn);
                                    }
                                });
                            }
                        }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                        double progress = (100 * taskSnapshot.getBytesTransferred() / taskSnapshot.getTotalByteCount());
                        progressDialog.setMessage("Image Uploading " + progress + "%");

                    }
                });

            }



        }else if (requestCode == REQ_CODE_WANT && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri saveUri = data.getData();
            if (saveUri != null) {
                final ProgressDialog progressDialog = new ProgressDialog(this);
                progressDialog.setMessage("Please Wait...");
                progressDialog.setCancelable(false);
                progressDialog.show();

                String name = UUID.randomUUID().toString();
                final StorageReference imageFolder = imageRef.child("images/" + name);
                imageFolder.putFile(saveUri)
                        .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {

                                imageFolder.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                    @Override
                                    public void onSuccess(Uri uri) {
                                        progressDialog.dismiss();
                                        wantImageUri = uri;
                                        Toast.makeText(PostProduct.this, "Image Uploaded!", Toast.LENGTH_SHORT).show();

                                        Picasso.with(getApplicationContext()).load(wantImageUri).into(wantImage);
                                    }
                                });
                            }
                        }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                        double progress = (100 * taskSnapshot.getBytesTransferred() / taskSnapshot.getTotalByteCount());
                        progressDialog.setMessage("Image Uploading " + progress + "%");

                    }
                });

            }



        }

    }

    private void uploadData() {

        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Please Wait...");
        progressDialog.setMessage("While uploading post!");
        progressDialog.setCancelable(false);

        String title = postTitle.getText().toString();
        String desc = postDesc.getText().toString();
        String price = postPrice.getText().toString();
        String address = postAddress.getText().toString();
        String city = postCity.getText().toString();
        String selectedCategory = (String) spinner.getSelectedItem();
        String wantProductTitle = wantTitle.getText().toString();
        String wantProductDesc = wantDesc.getText().toString();


        progressDialog.show();
        if(!TextUtils.isEmpty(title) && !TextUtils.isEmpty(desc) && !TextUtils.isEmpty(price) && !TextUtils.isEmpty(address)
        && !TextUtils.isEmpty(city) && !TextUtils.isEmpty(selectedCategory) && !TextUtils.isEmpty(String.valueOf(haveimageUri))
        && !TextUtils.isEmpty(String.valueOf(wantImageUri)) && !TextUtils.isEmpty(wantProductTitle) && !TextUtils.isEmpty(wantProductDesc)){


            ProductInfo productInfo = new ProductInfo(title, price, desc, String.valueOf(haveimageUri) ,address, city, String.valueOf(wantImageUri), wantProductTitle, wantProductDesc,FirebaseAuth.getInstance().getCurrentUser().getUid(), StaticData.currentUser.getName());
            databaseReference.child(selectedCategory).push().setValue(productInfo).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if(task.isSuccessful()){
                        progressDialog.dismiss();
                        Intent intent = new Intent(PostProduct.this, Home.class);
                        startActivity(intent);
                        finish();
                    }
                }
            });


        }else{
            progressDialog.dismiss();
            Toast.makeText(this, "Kindly fill required information!", Toast.LENGTH_SHORT).show();
        }
    }
}
