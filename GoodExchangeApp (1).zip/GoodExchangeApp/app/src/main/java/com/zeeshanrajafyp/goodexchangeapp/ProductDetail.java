package com.zeeshanrajafyp.goodexchangeapp;

import android.content.Intent;
import android.media.Image;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;
import com.zeeshanrajafyp.goodexchangeapp.Data.Notification;
import com.zeeshanrajafyp.goodexchangeapp.Data.Sender;
import com.zeeshanrajafyp.goodexchangeapp.Data.StaticData;
import com.zeeshanrajafyp.goodexchangeapp.Server.MessagingService;
import com.zeeshanrajafyp.goodexchangeapp.Server.ServerResponse;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProductDetail extends AppCompatActivity {

    ImageView productImage, wantProductImage;
    TextView titleTv, wantProductTitle;
    TextView descTv, wantProductDesc, postByTv;
    TextView priceTv;
    TextView addressTv;
    FloatingActionButton fab;
    Button exchangeFab;
    private String uid;
    MessagingService messagingService;
    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_detail);

        messagingService = StaticData.getService();

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);



        databaseReference = FirebaseDatabase.getInstance().getReference("tokens");

        productImage = (ImageView) findViewById(R.id.detailitemImage);
        wantProductImage = (ImageView) findViewById(R.id.wantdetailitemImage);

        titleTv = (TextView) findViewById(R.id.detailItemTitle);
        wantProductTitle = (TextView) findViewById(R.id.wantProductTitles);

        descTv = (TextView) findViewById(R.id.detailItemDesc);
        wantProductDesc = (TextView) findViewById(R.id.wantProductDetails);
        priceTv = (TextView) findViewById(R.id.detailItemPrice);
        addressTv = (TextView) findViewById(R.id.detailItemDetailAddress);
        postByTv = (TextView) findViewById(R.id.postBy);
        exchangeFab = (Button) findViewById(R.id.exchangeBtn);
        fab = (FloatingActionButton) findViewById(R.id.fabChat);

        if(getIntent().getExtras() != null){

            Picasso.with(this).load(getIntent().getStringExtra("image")).into(productImage);
            Picasso.with(this).load(getIntent().getStringExtra("wantImage")).into(wantProductImage);

            titleTv.setText(getIntent().getStringExtra("name"));
            wantProductTitle.setText(getIntent().getStringExtra("wantTitle"));
            descTv.setText(getIntent().getStringExtra("desc"));
            wantProductDesc.setText(getIntent().getStringExtra("wantDesc"));
            priceTv.setText("Rs:"+getIntent().getStringExtra("price"));
            addressTv.setText(""+getIntent().getStringExtra("address"));
            getSupportActionBar().setTitle(getIntent().getStringExtra("name"));
            uid = getIntent().getStringExtra("uid");
            postByTv.setText("Post by : "+getIntent().getStringExtra("postBy"));


        }





        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(ProductDetail.this, ChatingActivity.class);
                intent.putExtra("uid", uid);
                startActivity(intent);
            }
        });

        exchangeFab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                databaseReference.child(uid).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        String userToken =  dataSnapshot.child("token").getValue().toString();
                        Log.d("token", userToken);

                        Notification notification = new Notification("exchangeRequest", "Exchange Request");
                        Sender data = new Sender(userToken, notification);
                        messagingService.sendMessage(data).enqueue(new Callback<ServerResponse>() {
                            @Override
                            public void onResponse(Call<ServerResponse> call, Response<ServerResponse> response) {
                                if(response.body().success == 1){
                                    Toast.makeText(ProductDetail.this, "Goods Exchange Message Send!", Toast.LENGTH_SHORT).show();
                                }else{
                                    Toast.makeText(ProductDetail.this, "Message Sending Failed!", Toast.LENGTH_SHORT).show();
                                }
                            }

                            @Override
                            public void onFailure(Call<ServerResponse> call, Throwable t) {

                                Log.e("Error", t.getMessage());
                            }
                        });

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });


            }
        });

        if(FirebaseAuth.getInstance().getCurrentUser().getUid().equals(uid)){
            fab.setVisibility(View.GONE);
            exchangeFab.setVisibility(View.GONE);
        }

    }


}
