package com.zeeshanrajafyp.goodexchangeapp;


import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Layout;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.jaredrummler.materialspinner.MaterialSpinner;
import com.mancj.materialsearchbar.MaterialSearchBar;
import com.squareup.picasso.Picasso;
import com.zeeshanrajafyp.goodexchangeapp.Data.CategoryInfo;
import com.zeeshanrajafyp.goodexchangeapp.Data.ProductInfo;
import com.zeeshanrajafyp.goodexchangeapp.Data.StaticData;

import java.util.ArrayList;
import java.util.List;

public class SearchActivity extends AppCompatActivity {

    MaterialSearchBar searchBar;
    RecyclerView recyclerView;
    FirebaseRecyclerAdapter<ProductInfo, SearchActivity.ViewHolder> adapter;
    DatabaseReference categoryRef, itemRef;
    ArrayList<ProductInfo> itemList;
    MaterialSpinner categorySpinner;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        itemList = new ArrayList<>();

        categoryRef = FirebaseDatabase.getInstance().getReference("CategoryItems");
        itemRef = FirebaseDatabase.getInstance().getReference("CategoryItems");
        searchBar = (MaterialSearchBar) findViewById(R.id.searchBar);
        categorySpinner = (MaterialSpinner) findViewById(R.id.categorySpinner);

        final ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, StaticData.CategoryNames);
        categorySpinner.setAdapter(adapter);
        categorySpinner.setOnItemSelectedListener(new MaterialSpinner.OnItemSelectedListener() {
            @Override
            public void onItemSelected(MaterialSpinner view, int position, long id, Object item) {
                StaticData.currentCategory = adapter.getItem(position);
            }
        });

        recyclerView = (RecyclerView) findViewById(R.id.searchRecyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));


        searchBar.setOnSearchActionListener(new MaterialSearchBar.OnSearchActionListener() {
            @Override
            public void onSearchStateChanged(boolean enabled) {

            }

            @Override
            public void onSearchConfirmed(CharSequence text) {
                if(!TextUtils.isEmpty(text.toString())) {
                    loadDataFromDB(text.toString());
                }
            }
            @Override
            public void onButtonClicked(int buttonCode) {

            }
        });



    }

    private void loadDataFromDB(final String title) {

//        categoryRef.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
//
//                itemList = new ArrayList<>();
//
//                for(final DataSnapshot dataSnapshot1: dataSnapshot.getChildren()){
//                    CategoryInfo categoryInfo = dataSnapshot1.getValue(CategoryInfo.class);
//                    itemRef.child(categoryInfo.getName()).addValueEventListener(new ValueEventListener() {
//                        @Override
//                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
//
//
//                                for (DataSnapshot dataSnapshot2 : dataSnapshot.getChildren()) {
//                                    ProductInfo productInfo = dataSnapshot2.getValue(ProductInfo.class);
//                                    itemList.add(productInfo);
//                                    Log.d("Products", productInfo.getName() + "");
//                                }
//
//
//
//                        }
//
//                        @Override
//                        public void onCancelled(@NonNull DatabaseError databaseError) {
//
//                        }
//                    });
//                    Log.d("TAg", categoryInfo.getName()+"");
//                }
//
//
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError databaseError) {
//
//            }
//        });
//
//        for(int i = 0; i< itemList.size(); i++){
//            if(title.equals(itemList.get(i).getName())){
//
//            }else if(!title.equals(itemList.get(i).getName())){
//                itemList.remove(i);
//            }
//        }
//
//        MyAdapter adapter = new MyAdapter(itemList);
//        Log.d("Size", itemList.size()+"");
//        recyclerView.setAdapter(adapter);
//        adapter.notifyDataSetChanged();

        final Query query = FirebaseDatabase.getInstance()
                .getReference("CategoryItems").child(StaticData.currentCategory).orderByChild("name").startAt(title);

        FirebaseRecyclerOptions<ProductInfo> options = new FirebaseRecyclerOptions.Builder<ProductInfo>().setQuery(query, ProductInfo.class).build();

        adapter = new FirebaseRecyclerAdapter<ProductInfo, SearchActivity.ViewHolder>(options) {
            @Override
            protected void onBindViewHolder(@NonNull final ViewHolder holder, final int position, @NonNull final ProductInfo model) {



//                Toast.makeText(SearchActivity.this, "Found!", Toast.LENGTH_SHORT).show();

//                Toast.makeText(SearchActivity.this, ""+model.getName(), Toast.LENGTH_SHORT).show();

                Picasso.with(SearchActivity.this).load(model.getImage()).into(holder.imageView);
                holder.titleTv.setText(model.getName());
                holder.priceTxt.setText("Rs:"+model.getPrice());

                Log.d("Toast", adapter.getRef(position).getKey());
                holder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(SearchActivity.this, ProductDetail.class);

                        intent.putExtra("name", model.getName());
                        intent.putExtra("image", model.getImage());
                        intent.putExtra("desc", model.getDesc());
                        intent.putExtra("price", model.getPrice());
                        intent.putExtra("address", model.getAddress());
                        intent.putExtra("wantTitle", model.getWpTitle());
                        intent.putExtra("wantDesc", model.getDesc());
                        intent.putExtra("wantImage", model.getWpImage());
                        intent.putExtra("uid", model.getUid());


                        startActivity(intent);
                    }
                });
//
////

            }

            @NonNull
            @Override
            public SearchActivity.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
                View itemView = LayoutInflater.from(getApplicationContext()).inflate(R.layout.item_detail_layout, viewGroup, false);
                return new SearchActivity.ViewHolder(itemView);
            }
        };
        adapter.startListening();
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();

    }

    class ViewHolder extends RecyclerView.ViewHolder {

        ImageView imageView;
        TextView titleTv, priceTxt;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            imageView = (ImageView) itemView.findViewById(R.id.itemImage);
            titleTv = (TextView) itemView.findViewById(R.id.itemTitle);
            priceTxt = (TextView) itemView.findViewById(R.id.itemPrice);
        }
    }

//    class MyAdapter extends RecyclerView.Adapter<ViewHolder> {
//
//        List<ProductInfo> productInfoList;
//
//        public MyAdapter(List<ProductInfo> productInfoList) {
//            this.productInfoList = productInfoList;
//        }
//
//        @NonNull
//        @Override
//        public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
//            View view = LayoutInflater.from(getApplicationContext()).inflate(R.layout.item_detail_layout, viewGroup, false);
//            return new ViewHolder(view);
//        }
//
//        @Override
//        public void onBindViewHolder(@NonNull ViewHolder holder, final int i) {
//
//            Picasso.with(SearchActivity.this).load(productInfoList.get(i).getImage()).into(holder.imageView);
//            holder.titleTv.setText(productInfoList.get(i).getName());
//            holder.priceTxt.setText("Rs:" + productInfoList.get(i).getPrice());
//
////            Log.d("Toast", adapter.getRef(i).getKey());
//            holder.itemView.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    Intent intent = new Intent(SearchActivity.this, ProductDetail.class);
//
//                    intent.putExtra("name", productInfoList.get(i).getName());
//                    intent.putExtra("image", productInfoList.get(i).getImage());
//                    intent.putExtra("desc", productInfoList.get(i).getDesc());
//                    intent.putExtra("price", productInfoList.get(i).getPrice());
//                    intent.putExtra("address", productInfoList.get(i).getAddress());
//                    intent.putExtra("wantTitle", productInfoList.get(i).getWpTitle());
//                    intent.putExtra("wantDesc", productInfoList.get(i).getDesc());
//                    intent.putExtra("wantImage", productInfoList.get(i).getWpImage());
//                    intent.putExtra("uid", productInfoList.get(i).getUid());
//
//
//                    startActivity(intent);
//                }
//            });
//        }
//
//        @Override
//        public int getItemCount() {
//            return productInfoList.size();
//        }
//    }


    @Override
    protected void onStart() {
        super.onStart();


    }


    @Override
    protected void onStop() {
        if(adapter != null)
            adapter.stopListening();
        super.onStop();

    }


}
