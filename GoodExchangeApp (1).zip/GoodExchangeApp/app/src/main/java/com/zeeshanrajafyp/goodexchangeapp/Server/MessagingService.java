package com.zeeshanrajafyp.goodexchangeapp.Server;

import com.zeeshanrajafyp.goodexchangeapp.Data.Sender;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface MessagingService {

    @Headers({
            "Content-Type:application/json",
            "Authorization:key=AAAAepkOysc:APA91bFBPzf2A8ISVdSD3WLjyAU5ionkUeOl-0wWGz6n18m6i_8Uijad-QUb7k9y-IJhm-a0cbbH6Uo1hPUCSEhJauT6X8oqG6aTMC8pJXHKPBjlT9vYaS-kHtCdQou2ALu0WvKvALm3"
    })

    @POST("fcm/send")
    Call<ServerResponse> sendMessage(@Body Sender body);
}
