package com.zeeshanrajafyp.goodexchangeapp.Service;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.google.firebase.messaging.RemoteMessage;
import com.zeeshanrajafyp.goodexchangeapp.Home;
import com.zeeshanrajafyp.goodexchangeapp.R;

import java.util.Random;

public class FirebaseMessagingService extends com.google.firebase.messaging.FirebaseMessagingService {

    @Override
    public void onNewToken(String s) {
        super.onNewToken(s);

        DatabaseReference tokenRef = FirebaseDatabase.getInstance().getReference("tokens");

        if(FirebaseAuth.getInstance().getCurrentUser() != null){
            tokenRef.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).setValue(s);
        }
    }


    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {



        if(remoteMessage.getNotification().getBody().equals("Exchange Request")){
            Log.d("Test", "Ok");
            sendNotification(remoteMessage.getNotification().getTitle(),remoteMessage.getNotification().getBody());
        }else if(remoteMessage.getNotification().getTitle().equals("chatNotification")){
            sendNotification(remoteMessage.getNotification().getTitle(),remoteMessage.getNotification().getBody());

        }




    }

    private void sendNotification(String title ,String content) {
        Notification.Builder builder = new Notification.Builder(this)
                .setSmallIcon(R.mipmap.ic_launcher_round)
                .setContentTitle(title)

                .setContentText(content);

        NotificationManager manager = (NotificationManager)this.getSystemService(Context.NOTIFICATION_SERVICE);
        Intent intent = new Intent(this, Home.class);
        PendingIntent contentIntent = PendingIntent.getActivity(this, 0,intent, PendingIntent.FLAG_IMMUTABLE);
        builder.setContentIntent(contentIntent);
        Notification notification = builder.build();
        notification.flags |= Notification.FLAG_AUTO_CANCEL;


        notification.defaults = Notification.DEFAULT_LIGHTS | Notification.DEFAULT_VIBRATE;
        manager.notify(new Random().nextInt(), notification);
    }
}
