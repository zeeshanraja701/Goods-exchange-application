package com.zeeshanrajafyp.goodexchangeapp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.zeeshanrajafyp.goodexchangeapp.Data.StaticData;
import com.zeeshanrajafyp.goodexchangeapp.Data.UserData;

public class SignUp extends AppCompatActivity {

    FirebaseAuth mAuth;
    DatabaseReference userDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        mAuth  = FirebaseAuth.getInstance();
        userDB  = FirebaseDatabase.getInstance().getReference("Users");
    }

    public void RegistrationAcount(View view) {


        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please Wait...");
        progressDialog.show();

        final TextInputLayout userName = (TextInputLayout) findViewById(R.id.userNameEt);
        final TextInputLayout userEmail = (TextInputLayout) findViewById(R.id.userEmailEt);
        final TextInputLayout userPassword = (TextInputLayout) findViewById(R.id.userPasswordEt);
        final TextInputLayout userPhone = (TextInputLayout) findViewById(R.id.userPhoneEt);



        if(!TextUtils.isEmpty(userName.getEditText().getText().toString()) && !TextUtils.isEmpty(userEmail.getEditText().getText().toString()) &&
                !TextUtils.isEmpty(userPassword.getEditText().getText().toString()) && !TextUtils.isEmpty(userPhone.getEditText().getText().toString())){
            mAuth.createUserWithEmailAndPassword(userEmail.getEditText().getText().toString(), userPassword.getEditText().getText().toString()).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if(task.isSuccessful()) {
                        progressDialog.dismiss();
                        UserData userData = new UserData(userName.getEditText().getText().toString(), userEmail.getEditText().getText().toString(),
                                userPassword.getEditText().getText().toString(), userPhone.getEditText().getText().toString());
                        StaticData.currentUser = userData;
                        userDB.child(mAuth.getCurrentUser().getUid()).setValue(userData);
                        Intent loginIntent = new Intent(SignUp.this, LoginActivity.class);
                        startActivity(loginIntent);
                        finish();
                        Toast.makeText(SignUp.this, "User Register Successfully!", Toast.LENGTH_SHORT).show();
                    }
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    progressDialog.dismiss();
                    Toast.makeText(SignUp.this, "Failed To Create Account!", Toast.LENGTH_SHORT).show();
                }
            });
        }else{
            progressDialog.dismiss();
            Toast.makeText(this, "Enter Required Information To Register Account!", Toast.LENGTH_SHORT).show();
        }


    }
}
