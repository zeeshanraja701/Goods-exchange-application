package com.zeeshanrajafyp.goodexchangeapp;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Picasso;
import com.zeeshanrajafyp.goodexchangeapp.Data.ProductInfo;
import com.zeeshanrajafyp.goodexchangeapp.Data.StaticData;

import java.io.Serializable;

public class UserItems extends AppCompatActivity {

    RecyclerView recyclerView;
    FirebaseRecyclerAdapter<ProductInfo, UserItems.ViewHolder> adapter;
    DatabaseReference databaseRef;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_items);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);



//        Log.d("CurrentCate", ""+StaticData.currentCategory);

        recyclerView = (RecyclerView) findViewById(R.id.userItemsRecyclerview);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
//        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        if(getIntent() != null){

            StaticData.currentCategory = getIntent().getStringExtra("cateName");
            Toast.makeText(this, ""+StaticData.currentCategory, Toast.LENGTH_SHORT).show();
            getSupportActionBar().setTitle(StaticData.currentCategory);

        }


        databaseRef = FirebaseDatabase.getInstance().getReference("CategoryItems").child(StaticData.currentCategory);


        initalizedAdapter();
    }

    private void initalizedAdapter() {

        FirebaseRecyclerOptions<ProductInfo> options = new FirebaseRecyclerOptions.Builder<ProductInfo>().setQuery(databaseRef.orderByKey(), ProductInfo.class).build();

        adapter = new FirebaseRecyclerAdapter<ProductInfo, UserItems.ViewHolder>(options) {
            @Override
            protected void onBindViewHolder(@NonNull UserItems.ViewHolder holder, final int position, @NonNull final ProductInfo model) {
                if(model.getUid().equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
                    Toast.makeText(UserItems.this, ""+model.getUid(), Toast.LENGTH_SHORT).show();
                    Picasso.with(UserItems.this).load(model.getImage()).into(holder.imageView);
                    holder.titleTv.setText(model.getName());
                    holder.priceTxt.setText("Rs:" + model.getPrice());


                    holder.itemView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

//                            Intent intent = new Intent(UserItems.this, ProductDetail.class);
//
//                            intent.putExtra("name", model.getName());
//                            intent.putExtra("image", model.getImage());
//                            intent.putExtra("desc", model.getDesc());
//                            intent.putExtra("price", model.getPrice());
//                            intent.putExtra("address", model.getAddress());
//                            intent.putExtra("wantTitle", model.getWpTitle());
//                            intent.putExtra("wantDesc", model.getDesc());
//                            intent.putExtra("wantImage", model.getWpImage());
//                            intent.putExtra("uid", model.getUid());
//
//
//                            startActivity(intent);
                                showOptionsDialog(adapter.getRef(position).getKey(),model);

                        }
                    });

                }else{
                    holder.itemCard.setVisibility(View.GONE);

                }
            }

            @NonNull
            @Override
            public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
                View itemView = LayoutInflater.from(getApplicationContext()).inflate(R.layout.user_item_layout, viewGroup, false);
                return new ViewHolder(itemView);
            }


        };

        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
    }

    private void showOptionsDialog(final String key, final ProductInfo model) {


        AlertDialog.Builder builder = new AlertDialog.Builder(UserItems.this);
        builder.setTitle("Select Option");



        View deptView = LayoutInflater.from(UserItems.this).inflate(R.layout.user_item_options, null);


        Button editPost = (Button) deptView.findViewById(R.id.editPost);
        Button deletePost = (Button) deptView.findViewById(R.id.deletePost);

        editPost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent postIntent = new Intent(UserItems.this, EidtPostActivity.class);
                postIntent.putExtra("name", model.getName() );
                postIntent.putExtra("price", model.getPrice() );
                postIntent.putExtra("desc", model.getDesc() );
                postIntent.putExtra("image", model.getImage() );
                postIntent.putExtra("address", model.getAddress() );
                postIntent.putExtra("city", model.getCity() );
                postIntent.putExtra("wpImage", model.getWpImage() );
                postIntent.putExtra("wpTitle", model.getWpTitle() );
                postIntent.putExtra("wpDesc", model.getWpDesc() );
                postIntent.putExtra("uid", model.getUid() );
                postIntent.putExtra("postId", key);




                startActivity(postIntent);
            }
        });

        deletePost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                databaseRef.child(key).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(UserItems.this, "Post Deleted Successfully!", Toast.LENGTH_SHORT).show();
                        }     
                    }
                });
            }
        });

        builder.setView(deptView);


        builder.show();
    }

    class ViewHolder extends RecyclerView.ViewHolder{
        CardView itemCard;
        ImageView imageView;
        TextView titleTv, priceTxt;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            itemCard = (CardView) itemView.findViewById(R.id.itemCard);
            imageView = (ImageView) itemView.findViewById(R.id.itemImage);
            titleTv = (TextView) itemView.findViewById(R.id.itemTitle);
            priceTxt = (TextView) itemView.findViewById(R.id.itemPrice);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    protected void onStop() {
        adapter.stopListening();
        super.onStop();

    }
}
